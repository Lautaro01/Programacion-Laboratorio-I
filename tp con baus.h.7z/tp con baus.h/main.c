#include <stdio.h>
#include <stdlib.h>

typedef struct{
    int dia;
    int mes;
    int anio;
}eFecha;

typedef struct{
    int legajo;
    char nombre[21];
    char sexo;
    float sueldo;
    eFecha fechaIngreso;
    int isEmpty;
}eEmpleado;


int funcionMenu();
void inicializarEmpleados(eEmpleado emp[],int tam);
int buscarLibre(eEmpleado emp[],int tam);
void alta(eEmpleado emp[],int tam);
int buscarEmpleado(eEmpleado emp[],int tam,int legajo);

int main()
{

eEmpleado empleado[50];
int salir = 0;
inicializarEmpleados(empleado,50);

do{

    int funcionMenu();

    switch(funcionMenu()){
    case 1:
        printf("alta\n");
        system("pause");
        system("cls");
        break;
    case 2:
        printf("baja\n");
        system("pause");
        system("cls");
        break;
    case 3:
        printf("modificacion\n");
        system("pause");
        system("cls");
        break;
    case 4:
        printf("listar\n");
        system("pause");
        system("cls");
        break;
    case 5:
        printf("Ordenar\n");
        system("pause");
        system("cls");
        break;
    case 6:
        printf("salir\n");
        salir = 1;
        system("pause");
        system("cls");
        break;
    default:
        printf("Opcion incorrecta!");
        break;
    }

}while(salir != 1);

    return 0;
}

int funcionMenu(){


        int opcion;
        system("cls");
        printf("---BAUS.H MENU FUNCION---\n\n");
        printf("1-Dar de alta\n");
        printf("2-Dar de baja\n");
        printf("3-Modoficacion\n");
        printf("4-Listar\n");
        printf("5-Ordenar\n");
        printf("6-Salir\n\n");

        printf("Ingrese opcion: ");
        scanf("%d",&opcion);

    return opcion;
}//funcion

void inicializarEmpleados(eEmpleado emp[],int tam){

    for(int i=0;i<tam;i++)
    {
        emp[i].isEmpty = 1;
    }
}

int buscarLibre(eEmpleado emp[],int tam){
int indice = -1;
for(int i=0;i<tam;i++){
    if(emp[i].isEmpty == 1){
        indice = i;
        break;
    }
}
return indice;
}

void alta(eEmpleado emp[], int tam){

int legajo;
int existe;
int indice = buscarLibre(emp,tam);

if(indice<0){
    printf("no hay lugar");
}
else{
        printf("\nLegajo: ");
        scanf("%d", &emp[indice].legajo);

        existe = buscarEmpleado(emp,tam,legajo);

        if(existe == -1)
        {
            printf("\nNombre: ");
            fflush(stdin);
            scanf("%s", emp[i].nombre);

            printf("\nSueldo: ");
            scanf("%f", &emp[i].sueldo);

            printf("\n--Fecha de inicializacion--\n")

            printf("Dia: ");
            scanf("%d", &emp[i].fechaIngreso.dia);

            printf("\nMes: ");
            scanf("%d", &emp[i].fechaIngreso.mes);

            printf("\nA�o: ");
            scanf("%d", &emp[i].fechaIngreso.anio);

            emp[i].isEmpty = 0;

            break;
        }
        else{
            printf("El legajo ya existe");
        }
}
}
}
}
}//funcion

int buscarEmpleado(eEmpleado emp[],int tam,int legajo){

int existe = -1;
for(i=0;i<tam;i++){
    if(emp[i].legajo == legajo)
    {
        existe = i;
        break;
    }
}
return existe;
}
