#include <stdio.h>
#include <stdlib.h>
#define  TAMN 3
#define

typedef struct {
    int dia, mes, anio;
}eFecha;

typedef struct{
    char nombre[50];
    int legajo;
    char sexo;
    float sueldo;
    eFecha fechaIngreso;
    int isEmpty;
}eEmpleado;

typedef struct{
    int id;
    char descripcion;
    int isEmpty;
}eSector;


listarEmpleados(eEmpleado emp[],int tamn,eSector sec[],int tamn2 ){

for(int i=0;i<tam;i++){
    for(int j=0;j<tam2;j++){

        if(emp[i].idSector == sec[j].id){
            "%d",emp[i].legajo
            "%s",emp[i].nombre
            "%s",sec[j].descripcion
        }
    }
}
}
listar sectores por empleado(eEmpleado emp[],int tamn,eSector sec[],int tamn2){

    for(int i=0;i<tam2;i++){
            print
    for(int j=0;j<tam;j++){
        if(sec[i].id == emp[j].idSector){

        }
    }
}

}


